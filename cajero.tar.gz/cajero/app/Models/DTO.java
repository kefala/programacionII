package com.cajero.app.Models;

import java.io.Serializable;

/**
 * Created by kefala on 19/06/16.
 */
public class DTO implements Serializable {
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
